ELEVATED MASSES — BEGINNER STARTER PACK
========================================

Welcome! This pack has everything you need to get your first grow going:

1. RDWC 1-Pot Build Guide (rdwc-1-pot-build.pdf)
   The simplest recirculating hydro build — one grow bucket, one weekend.

2. Nutrient Mixing Cheat Sheet (nutrient-mixing-cheat-sheet.pdf)
   PPM/EC/pH targets by growth stage, plus quick conversion formulas.

3. Weekly Grow Checklist (weekly-grow-checklist.pdf)
   A printable routine so nothing slips between feedings.

Print the checklist and stick it near your grow space — the two-minute
daily check is the single best habit for catching problems early.

Questions? info@elevatedmasses.com
Grow, share, and stay elevated. — Elevated Masses LLC
